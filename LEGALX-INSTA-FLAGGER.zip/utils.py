from urllib.parse import urlparse

def validate_url(url):
    try:
        parsed = urlparse(url)
        return "instagram.com" in parsed.netloc
    except:
        return False

def get_report_reason(reason_id):
    reasons = {
        "1": "nudity_or_sexual_activity",
        "2": "hate_speech_or_symbols",
        "3": "spam",
        "4": "impersonation",
        "5": "harassment_or_bullying"
    }
    return reasons.get(reason_id, None)
