# LEGALX-INSTA FLAGGER

> Built by **Zonnyxxd** under the brand **LEGAL X**

A Python tool for ethically reporting abusive Instagram content: hate speech, nudity, impersonation, and spam.

## Features

- Accepts IG profile or post URLs
- Uses your valid browser session cookie
- Sends clean reports via official endpoints
- Open-source, educational purpose only

## How to Use

1. Clone the repo.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Extract `sessionid` from your logged-in Instagram browser:
   - Open DevTools → Application → Cookies → Copy value of `sessionid`
   - Paste it into `config.ini`

4. Run:

```bash
python main.py
```

## Disclaimer
This tool is for **educational and ethical** use only.
