# multi_report.py

import csv
import time
import random
from utils import validate_url, get_report_reason
from reporter import send_report

def load_targets_from_csv(filename):
    targets = []
    try:
        with open(filename, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                url = row.get("url", "").strip()
                reason_id = row.get("reason", "").strip()
                if url and reason_id and validate_url(url):
                    reason_key = get_report_reason(reason_id)
                    if reason_key:
                        targets.append((url, reason_key))
    except Exception as e:
        print(f"❌ Failed to read {filename}: {e}")
    return targets

def run_batch_reporting(filename, min_delay=3, max_delay=7):
    print(f"📄 Loading targets from: {filename}")
    targets = load_targets_from_csv(filename)
    print(f"🔍 {len(targets)} valid targets loaded.")

    for idx, (url, reason) in enumerate(targets, start=1):
        print(f"🔁 [{idx}/{len(targets)}] Reporting: {url} - {reason}")
        success, message = send_report(url, reason)
        print("✅" if success else "❌", message)

        if idx < len(targets):
            delay = random.randint(min_delay, max_delay)
            print(f"⏳ Waiting {delay} seconds before next report...")
            time.sleep(delay)

if __name__ == "__main__":
    print("🛡️ InstaFlagger Multi-Report Mode (Rate Limited)")
    filename = input("Enter the CSV filename (with .csv extension): ").strip()
    run_batch_reporting(filename)
