import requests
import configparser
from fake_useragent import UserAgent

def load_session():
    config = configparser.ConfigParser()
    config.read('config.ini')
    sessionid = config['AUTH']['sessionid']
    return sessionid

def send_report(target_url, reason):
    sessionid = load_session()
    headers = {
        "User-Agent": UserAgent().random,
        "Cookie": f"sessionid={sessionid};",
        "X-IG-App-ID": "936619743392459",
    }

    endpoint = "https://www.instagram.com/users/report/"
    payload = {
        "source_name": "profile",
        "reason_id": reason,
        "frx_context": "",
        "target_url": target_url,
    }

    response = requests.post(endpoint, headers=headers, data=payload)

    if response.status_code == 200:
        return True, "Reported successfully."
    elif response.status_code == 400:
        return False, "Bad request — session may be invalid."
    else:
        return False, f"Error: {response.status_code} - {response.text}"
