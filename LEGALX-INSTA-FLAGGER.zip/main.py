from utils import validate_url, get_report_reason
from reporter import send_report

def menu():
    print("Instagram Ethical Reporter - InstaFlagger")
    print("Enter abusive account or post URL:")
    url = input("> ").strip()

    if not validate_url(url):
        print("❌ Invalid Instagram URL.")
        return

    print("\nSelect abuse type to report:")
    print("1 - Nudity / Sexual Content")
    print("2 - Hate Speech")
    print("3 - Spam")
    print("4 - Impersonation")
    print("5 - Harassment or Bullying")
    reason_id = input("> ").strip()

    reason_key = get_report_reason(reason_id)
    if not reason_key:
        print("❌ Invalid reason code.")
        return

    print("\n⚙️ Sending report...")
    success, message = send_report(url, reason_key)
    print("✅" if success else "❌", message)

if __name__ == "__main__":
    menu()
