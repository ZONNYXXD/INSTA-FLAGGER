def validate_url(url):
    return "instagram.com" in url and ("http://" in url or "https://" in url)

def get_report_reason(reason_id):
    reasons = {
        "1": "nudity",
        "2": "hate_speech",
        "3": "spam",
        "4": "impersonation",
        "5": "harassment"
    }
    return reasons.get(reason_id)
