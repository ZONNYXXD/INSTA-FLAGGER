#!/usr/bin/env python3
import time
import random
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict
from utils import validate_url, get_report_reason
from reporter import send_report

ABUSE_TYPES = {
    "1": "Nudity / Sexual Content",
    "2": "Hate Speech",
    "3": "Spam",
    "4": "Impersonation",
    "5": "Harassment or Bullying"
}

def menu():
    print("LEGAL X Instagram Reporter - InstaFlagger [THREAD + PROXY + STATS]")

    try:
        url = input("\nEnter abusive account or post URL:\n> ").strip()
        if not validate_url(url):
            print("❌ Invalid Instagram URL.")
            return

        print("\nSelect abuse types to report (comma-separated):")
        for key, value in ABUSE_TYPES.items():
            print(f"{key} - {value}")
        abuse_input = input("> ").strip().split(",")

        abuse_counts = {}
        for abuse_id in abuse_input:
            abuse_id = abuse_id.strip()
            if abuse_id not in ABUSE_TYPES:
                print(f"❌ Invalid abuse type: {abuse_id}")
                return

            count = input(f"How many reports to send for '{ABUSE_TYPES[abuse_id]}'?\n> ").strip()
            if not count.isdigit() or int(count) <= 0:
                print("❌ Invalid number.")
                return
            abuse_counts[abuse_id] = int(count)

        delay = input("\nSet delay between threads (seconds) [default = 1]:\n> ").strip()
        delay = int(delay) if delay.isdigit() else 1

        max_threads = input("Max concurrent threads [default = 10]:\n> ").strip()
        max_threads = int(max_threads) if max_threads.isdigit() else 10

        start_time = datetime.datetime.now()
        stats = defaultdict(lambda: {"success": 0, "fail": 0})

        print("\n🚀 Starting multi-threaded report sequence...\n")

        tasks = []
        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            for abuse_id, count in abuse_counts.items():
                reason_key = get_report_reason(abuse_id)
                if not reason_key:
                    print(f"❌ Could not find reason for abuse ID {abuse_id}")
                    continue

                print(f"🔸 Scheduling {count} reports for: {ABUSE_TYPES[abuse_id]}")
                for _ in range(count):
                    tasks.append(executor.submit(send_report, url, reason_key))
                    time.sleep(delay)

            for i, future in enumerate(as_completed(tasks), 1):
                success, message = future.result()
                if success:
                    stats['success']["success"] += 1
                else:
                    stats['fail']["fail"] += 1
                print(f"[{i}/{len(tasks)}] {'✅' if success else '❌'} {message}")

        end_time = datetime.datetime.now()
        duration = end_time - start_time

        print("\n📊 REPORT SUMMARY")
        print("-" * 30)
        print(f"Start Time : {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"End Time   : {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Duration   : {duration}")
        print("-" * 30)
        print(f"Total Success : {stats['success']['success']}")
        print(f"Total Failed  : {stats['fail']['fail']}")

    except KeyboardInterrupt:
        print("\n🛑 Operation cancelled.")

if __name__ == "__main__":
    menu()
