import requests, configparser, random, itertools, threading

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 12_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
]

def test_proxy(proxy, timeout=5):
    proxies = {"http": proxy, "https": proxy}
    try:
        r = requests.get("https://www.google.com/generate_204", proxies=proxies, timeout=timeout)
        return r.status_code == 204
    except:
        return False

def load_sessions():
    sessions = []
    cfg = configparser.ConfigParser(interpolation=None)
    cfg.read("config.ini")
    if "AUTH" in cfg and "sessionid" in cfg["AUTH"]:
        sessions.append(cfg["AUTH"]["sessionid"].strip())
    try:
        with open("sessions.txt") as f:
            sessions.extend(line.strip() for line in f if line.strip())
    except FileNotFoundError:
        pass
    if not sessions:
        raise RuntimeError("No session IDs found.")
    lock = threading.Lock()
    cycle = itertools.cycle(sessions)
    def get_next_session():
        with lock:
            return next(cycle)
    return get_next_session

def load_proxies():
    try:
        with open("proxies.txt") as f:
            raw_proxies = [p.strip() for p in f if p.strip()]
    except FileNotFoundError:
        raw_proxies = []
    if not raw_proxies:
        print("⚠️  No proxies found. Using your IP.")
        return lambda: None
    print(f"\n🔍 Checking {len(raw_proxies)} proxies...\n")
    working = []
    for p in raw_proxies:
        if test_proxy(p):
            print(f"✅ Working: {p}")
            working.append(p)
        else:
            print(f"❌ Dead:    {p}")
    if not working:
        print("⚠️  No working proxies found. Will fallback to direct IP.")
        working = [None]
    lock = threading.Lock()
    cycle = itertools.cycle(working)
    def get_next_proxy():
        with lock:
            return next(cycle)
    return get_next_proxy

GET_SESSION = load_sessions()
GET_PROXY = load_proxies()

def send_report(target_url: str, reason: str, retries: int = 3):
    for attempt in range(1, retries + 1):
        sessionid = GET_SESSION()
        proxy = GET_PROXY()
        ua = random.choice(USER_AGENTS)
        headers = {
            "User-Agent": ua,
            "Cookie": f"sessionid={sessionid};",
            "X-IG-App-ID": "936619743392459",
        }
        proxies = {"http": proxy, "https": proxy} if proxy else None
        payload = {
            "source_name": "profile",
            "reason_id": reason,
            "frx_context": "",
            "target_url": target_url,
        }
        try:
            r = requests.post("https://www.instagram.com/users/report/",
                              headers=headers, data=payload,
                              proxies=proxies, timeout=10)
            if r.status_code == 200:
                return True, f"OK (UA:{ua.split()[0]} Proxy:{proxy or 'Direct'})"
            if r.status_code == 400:
                continue
            return False, f"{r.status_code} {r.text[:80]}..."
        except requests.exceptions.RequestException as e:
            continue
    return False, f"Failed after {retries} attempts"
